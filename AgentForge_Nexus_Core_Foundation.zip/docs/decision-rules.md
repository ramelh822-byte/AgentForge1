# Decision Rules and Portfolio Governance

## Opportunity score (0–100)
Default weighted model from the product brief:
- Demand: 30%
- Competition attractiveness: 20% (higher score means less competitive / more room)
- Automation potential: 20%
- Revenue potential: 20%
- Risk-adjusted safety: 10% (higher score means lower risk)

`score = 0.30*demand + 0.20*competition_attractiveness + 0.20*automation + 0.20*revenue_potential + 0.10*risk_adjusted_safety`

Do not treat a score as a fact. Store source evidence, confidence, date, and the raw component scores. Flag low-confidence or stale data.

## Initial gates
- Demand score > 70
- Competition attractiveness > 40 (equivalent to competition burden < 60)
- Automation score > 80
- A named customer problem, plausible willingness-to-pay signal, and at least one monetization path
- A traffic acquisition hypothesis and an explicit kill threshold
- Risk/compliance review before external launch

## Lifecycle
Discover → Research → Validate → Approve → Build → Launch → Measure → Optimize / Scale / Pause → Harvest / Retire.

## Suggested thresholds (configurable, not universal truths)
- Never launch without a monetization plan, target customer, traffic path, measurement plan, and kill criteria.
- No second capital tranche until the first experiment has been reviewed.
- Asset older than 180 days and revenue below $100/month enters review; it is not automatically deleted.
- Revenue above a configurable threshold triggers a replication review, not automatic duplication.
- Scale only when conversion, contribution margin, retention, traffic quality, and operational capacity support it.
- Kill or archive only after checking data quality, seasonality, attribution windows, customer obligations, contractual duties, and recovery cost.

## Capital allocation example
Default policy from the brief: 30% growth assets, 20% new experiments, 30% product expansion, 20% reserve. Treat as an editable starting policy, not financial advice or an automatic transfer instruction.

## Autonomy levels
L0 Observe → L1 Analyze → L2 Recommend → L3 Prepare changes → L4 Execute pre-approved reversible actions → L5 Bounded autonomous operation.
New workspaces default to L1/L2. External spend, publication, account changes, and destructive actions require explicit policy and authorization.

## Required audit fields
Actor/agent, timestamp, target, proposed action, evidence, expected impact, cost, approval status, actual outcome, rollback/compensation, and follow-up lesson.
