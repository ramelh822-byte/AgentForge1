-- PostgreSQL starter schema. Review and migrate through a migration tool before production.
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TYPE lifecycle_status AS ENUM (
  'discovered','researching','validating','approved','building','launched',
  'optimizing','scaling','paused','retiring','archived','killed'
);
CREATE TYPE decision_type AS ENUM ('scale','optimize','pause','retire','launch','reallocate','review');
CREATE TYPE approval_status AS ENUM ('draft','pending','approved','rejected','executed','cancelled');

CREATE TABLE workspaces (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE opportunities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  niche TEXT NOT NULL,
  customer_problem TEXT,
  target_audience TEXT,
  demand_score NUMERIC(5,2) CHECK (demand_score BETWEEN 0 AND 100),
  competition_attractiveness_score NUMERIC(5,2) CHECK (competition_attractiveness_score BETWEEN 0 AND 100),
  automation_score NUMERIC(5,2) CHECK (automation_score BETWEEN 0 AND 100),
  revenue_potential_score NUMERIC(5,2) CHECK (revenue_potential_score BETWEEN 0 AND 100),
  risk_adjusted_safety_score NUMERIC(5,2) CHECK (risk_adjusted_safety_score BETWEEN 0 AND 100),
  total_score NUMERIC(5,2) CHECK (total_score BETWEEN 0 AND 100),
  evidence JSONB NOT NULL DEFAULT '[]',
  monetization_paths JSONB NOT NULL DEFAULT '[]',
  traffic_hypothesis TEXT,
  validation_plan JSONB NOT NULL DEFAULT '[]',
  confidence NUMERIC(4,3) CHECK (confidence BETWEEN 0 AND 1),
  status lifecycle_status NOT NULL DEFAULT 'discovered',
  researched_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE assets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  opportunity_id UUID REFERENCES opportunities(id) ON DELETE SET NULL,
  asset_code TEXT NOT NULL,
  name TEXT NOT NULL,
  asset_type TEXT NOT NULL,
  niche TEXT NOT NULL,
  audience TEXT,
  status lifecycle_status NOT NULL DEFAULT 'building',
  monthly_revenue NUMERIC(14,2) NOT NULL DEFAULT 0,
  monthly_cost NUMERIC(14,2) NOT NULL DEFAULT 0,
  monthly_visitors BIGINT NOT NULL DEFAULT 0,
  subscribers BIGINT NOT NULL DEFAULT 0,
  conversion_rate NUMERIC(8,5),
  retention_rate NUMERIC(8,5),
  automation_score NUMERIC(5,2),
  risk_score NUMERIC(5,2),
  strategic_value_score NUMERIC(5,2),
  launched_at TIMESTAMPTZ,
  last_reviewed_at TIMESTAMPTZ,
  scale_threshold NUMERIC(14,2),
  kill_threshold NUMERIC(14,2),
  metadata JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(workspace_id, asset_code)
);

CREATE TABLE revenue_streams (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  asset_id UUID NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK (kind IN ('ads','affiliate','subscription','product','sponsorship','licensing','marketplace','other')),
  provider TEXT,
  external_reference TEXT,
  monthly_revenue NUMERIC(14,2) NOT NULL DEFAULT 0,
  currency CHAR(3) NOT NULL DEFAULT 'USD',
  attribution JSONB NOT NULL DEFAULT '{}',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE experiments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  asset_id UUID REFERENCES assets(id) ON DELETE SET NULL,
  opportunity_id UUID REFERENCES opportunities(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  hypothesis TEXT NOT NULL,
  primary_metric TEXT NOT NULL,
  success_threshold JSONB NOT NULL,
  kill_threshold JSONB NOT NULL,
  budget_cap NUMERIC(14,2) NOT NULL DEFAULT 0,
  spend NUMERIC(14,2) NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'planned',
  result JSONB NOT NULL DEFAULT '{}',
  started_at TIMESTAMPTZ,
  ended_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE metric_events (
  id BIGSERIAL PRIMARY KEY,
  workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  asset_id UUID REFERENCES assets(id) ON DELETE SET NULL,
  experiment_id UUID REFERENCES experiments(id) ON DELETE SET NULL,
  metric_name TEXT NOT NULL,
  metric_value NUMERIC(20,6) NOT NULL,
  unit TEXT,
  source TEXT NOT NULL,
  observed_at TIMESTAMPTZ NOT NULL,
  ingested_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  dimensions JSONB NOT NULL DEFAULT '{}'
);
CREATE INDEX metric_events_asset_time_idx ON metric_events(asset_id, observed_at DESC);
CREATE INDEX metric_events_workspace_time_idx ON metric_events(workspace_id, observed_at DESC);

CREATE TABLE agent_runs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  agent_name TEXT NOT NULL,
  task_type TEXT NOT NULL,
  input JSONB NOT NULL DEFAULT '{}',
  output JSONB NOT NULL DEFAULT '{}',
  evidence JSONB NOT NULL DEFAULT '[]',
  status TEXT NOT NULL DEFAULT 'queued',
  model_name TEXT,
  prompt_version TEXT,
  estimated_cost NUMERIC(12,6),
  actual_cost NUMERIC(12,6),
  started_at TIMESTAMPTZ,
  finished_at TIMESTAMPTZ,
  error JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE decisions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  asset_id UUID REFERENCES assets(id) ON DELETE SET NULL,
  opportunity_id UUID REFERENCES opportunities(id) ON DELETE SET NULL,
  decision decision_type NOT NULL,
  rationale TEXT NOT NULL,
  evidence JSONB NOT NULL DEFAULT '[]',
  expected_impact JSONB NOT NULL DEFAULT '{}',
  proposed_by TEXT NOT NULL,
  approval approval_status NOT NULL DEFAULT 'pending',
  approved_by TEXT,
  approved_at TIMESTAMPTZ,
  executed_at TIMESTAMPTZ,
  outcome JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE knowledge_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  category TEXT NOT NULL,
  lesson TEXT NOT NULL,
  context JSONB NOT NULL DEFAULT '{}',
  supporting_decision_ids UUID[] NOT NULL DEFAULT '{}',
  confidence NUMERIC(4,3) CHECK (confidence BETWEEN 0 AND 1),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
