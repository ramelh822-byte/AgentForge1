# Implementation Roadmap

## Phase 0 — Core foundation (this delivery)
- Define canonical data entities and scoring logic.
- Build an interactive dashboard prototype with sample assets and opportunities.
- Document agent boundaries, lifecycle gates, and governance.

## Phase 1 — Persistence and access
- Implement Next.js/TypeScript app, PostgreSQL schema/migrations, authentication, workspace roles, and audit log.
- Replace browser-only demo state with authenticated APIs.
- Add import/export and metric-source provenance.

## Phase 2 — Opportunity intelligence
- Connect approved trend, keyword, search, marketplace, and competitor sources.
- Build evidence-backed opportunity cards with freshness/confidence.
- Deduplicate ideas and generate validation plans.

## Phase 3 — Asset registry and experiments
- Track assets, owners, niche, lifecycle, costs, revenue streams, traffic channels, dependencies, and kill/scale thresholds.
- Add experiment templates and stage gates.
- Add event and conversion ingestion.

## Phase 4 — Content, traffic, capture
- Add reusable content briefs, editorial calendar, landing-page generator, lead magnet workflow, and email-provider integration.
- Human approval before publishing or sending campaigns.
- Respect consent, deliverability, copyright, and platform terms.

## Phase 5 — Monetization
- Add product/affiliate/subscription/sponsor/advertising revenue models.
- Integrate billing and partner tracking only after credentials and account authorization.
- Reconcile revenue, refunds, fees, and attribution windows.

## Phase 6 — Agent orchestration
- Add durable jobs, agent run records, tool allowlists, budgets, retries, evaluation, and prompt/version tracking.
- Each agent produces structured outputs and citations/evidence.
- Add approval inbox and emergency stop.

## Phase 7 — Portfolio intelligence
- Compare cohorts and channel economics.
- Recommend budget shifts and identify cannibalization, concentration, and attribution risks.
- Run controlled experiments before scaling.

## Phase 8 — Replication and bounded autonomy
- Convert winning workflows into templates.
- Launch variants only after approval gates.
- Retire assets through an archive/checklist workflow, never silent deletion.
- Continuously evaluate recommendations against actual outcomes.

## Definition of production-ready
- Real authentication and authorization
- Persisted database and backups
- Secrets management
- Tested integrations and data lineage
- Observability, error handling, and alerting
- Approval workflows and audit trail
- Security/privacy review
- Cost controls, rate limits, and rollback procedures
- Verified deployment and live health checks
