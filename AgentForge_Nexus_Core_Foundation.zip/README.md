# AgentForge Nexus — Core Foundation

AgentForge Nexus is a portfolio operating system for discovering, validating, launching, measuring, and scaling digital businesses.

## What's included
- `app/index.html`: interactive dashboard prototype; runs locally in a browser with no build step.
- `docs/architecture.md`: target system architecture and agent responsibilities.
- `docs/data-model.sql`: PostgreSQL starter schema for assets, opportunities, experiments, metrics, decisions, and knowledge.
- `docs/decision-rules.md`: scoring model, lifecycle gates, governance, and safety controls.
- `docs/roadmap.md`: phased implementation plan.

## Run
Open `app/index.html` in a browser. The prototype uses illustrative demo data and local browser state. It does not connect to real accounts, analytics, ad platforms, payment processors, email providers, or deploy websites.

## Important
All displayed business metrics are sample values based on the supplied concept, not verified live company data. Before production use, connect real data sources and configure credentials securely. Do not let an agent spend money, publish ads, send bulk email, delete assets, or make irreversible changes without explicit authorization and audit logging.

## Production direction
Suggested stack:
- Web: Next.js + TypeScript
- Database: PostgreSQL
- Auth: managed identity provider with role-based access
- Jobs: durable queue/workflow engine
- AI: model gateway with structured outputs, evaluation, and spend limits
- Analytics: event ingestion + warehouse/aggregations
- Integrations: Search Console/analytics, email provider, affiliate networks, billing, CMS, ad platforms
- Deployment: managed app host and managed database

This repository is the foundation/specification, not a deployed autonomous corporation.
